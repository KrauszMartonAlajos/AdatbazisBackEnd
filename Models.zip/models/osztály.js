const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) =>
{
    class Osztály extends Model {};

    Osztály.init
    (
        {
            azonosító:
            {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
                allowNull: false,
            },

            létszám:
            {
                type: DataTypes.INTEGER,
            },
        },

        {
            sequelize,
            modelName: "Osztály",
            freezeTableName: true,
            timestamps: false,
        }
    )
    
    return Osztály;
}