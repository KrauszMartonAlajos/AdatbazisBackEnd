const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) =>
{
    class Iskola extends Model {};

    Iskola.init
    (
        {
            azonosító:
            {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
                allowNull: false,
            },

            név:
            {
                type: DataTypes.STRING(30),
            },

            cím:
            {
                type: DataTypes.STRING(100),
            },

            létszám:
            {
                type: DataTypes.INTEGER,
            },
        },

        {
            sequelize,
            modelName: "Iskola",
            freezeTableName: true,
            timestamps: false,
        }
    )

    return Iskola;
}