module.exports = (sequelize, DataTypes) =>
{
    const Tanuló = require("../models/tanuló")(sequelize, DataTypes);

    const Osztály = require("../models/osztály")(sequelize, DataTypes);

    const Iskola = require("../models/iskola")(sequelize, DataTypes);

    const Tanár = require("../models/tanár")(sequelize, DataTypes);

    Iskola.hasMany(Tanuló, 
    {
        foreignKey: "iskolaAzonosító",
    });

    Iskola.belongsToMany(Tanár, 
    {
        foreignKey: "iskolaAzonosító",
        through: "Tanít",
    });

    Tanár.hasOne(Osztály,
    {
        foreignKey: "tanárAzonosító",
    });

    Tanár.belongsToMany(Iskola, 
    {
        foreignKey: "tanárAzonosító",
        through: "Tanít",
    });

    Osztály.hasMany(Tanuló, 
    {
        foreignKey: "osztályAzonosító",
    });

    return { Tanuló, Osztály, Iskola, Tanár };
}